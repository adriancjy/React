import flask
import requests, json, datetime

app = flask.Flask(__name__)


@app.route('/')
def hello_world():
    return 'Hello World!'


@app.route('/balance/<accID>')
def get_balance(accID):
    response = requests.get('http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/accounts/deposit/' + accID + '/balance',
                            headers={'identity': 'T7', 'token': 'af1c9e83-266a-4c97-80fa-25c84e2f39fd'}).json()
    return corsify_actual_response({'balance': response['availableBalance']})


@app.route('/credit/<accID>')
def get_debit(accID):
    response = requests.get(
        'http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/transactions/' + accID,
        params={'from': '01-01-2020', 'to': '01-30-2020'},
        headers={'identity': 'T7', 'token': 'af1c9e83-266a-4c97-80fa-25c84e2f39fd'})

    transactions = json.loads(response.text)
    credit_transactions = [transaction for transaction in transactions if transaction['type'] == 'CREDIT']
    sum = 0
    for debit in credit_transactions:
        sum = sum + float(debit['amount'])

    return corsify_actual_response({'credit': sum})


@app.route('/debit/<accID>')
def get_credit(accID):
    response = requests.get(
        'http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/transactions/' + accID,
        params={'from': '01-01-2020', 'to': '01-30-2020'},
        headers={'identity': 'T7', 'token': 'af1c9e83-266a-4c97-80fa-25c84e2f39fd'})

    transactions = json.loads(response.text)
    credit_transactions = [transaction for transaction in transactions if transaction['type'] == 'DEBIT']
    sum = 0
    for debit in credit_transactions:
        sum = sum + float(debit['amount'])

    return corsify_actual_response({'debit': round(sum, 2)})


@app.route('/debit_per_day/<accID>')
def get_debit_per_day(accID):
    response = requests.get(
        'http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/transactions/' + accID,
        params={'from': '01-01-2020', 'to': '01-30-2020'},
        headers={'identity': 'T7', 'token': 'af1c9e83-266a-4c97-80fa-25c84e2f39fd'})

    transactions = json.loads(response.text)
    debit_transactions = [transaction for transaction in transactions if transaction['type'] == 'DEBIT']
    days = [i for i in range(1, 31)]
    debit_per_day = []
    for day in days:
        debit_transactions_by_date = [transaction for transaction in debit_transactions if datetime.datetime.strptime(transaction['date'][:10], '%Y-%m-%d').day == day]
        sum = 0
        for debit_transaction in debit_transactions_by_date:
            sum = sum + float(debit_transaction['amount'])
        debit_per_day.append(round(sum, 2))

    return corsify_actual_response({'debit_per_day': debit_per_day})


@app.route('/credit_per_day/<accID>')
def get_credit_per_day(accID):
    response = requests.get(
        'http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/transactions/' + accID,
        params={'from': '01-01-2020', 'to': '01-30-2020'},
        headers={'identity': 'T7', 'token': 'af1c9e83-266a-4c97-80fa-25c84e2f39fd'})

    transactions = json.loads(response.text)
    credit_transactions = [transaction for transaction in transactions if transaction['type'] == 'CREDIT']
    days = [i for i in range(1, 31)]
    credit_per_day = []
    for day in days:
        credit_transactions_by_date = [transaction for transaction in credit_transactions if
                                      datetime.datetime.strptime(transaction['date'][:10], '%Y-%m-%d').day == day]
        sum = 0
        for credit_transaction in credit_transactions_by_date:
            sum = sum + float(credit_transaction['amount'])
        credit_per_day.append(round(sum, 2))
    print(credit_per_day)
    return corsify_actual_response({'credit_per_day': credit_per_day})
	
	
@app.route('/breakdown/<accID>')
def get_breakdown(accID):
    response = requests.get(
        'http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/transactions/' + accID,
        params={'from': '01-01-2020', 'to': '01-30-2020'},
        headers={'identity': 'T7', 'token': 'af1c9e83-266a-4c97-80fa-25c84e2f39fd'})

    transactions = json.loads(response.text)
    debits = [transaction for transaction in transactions if transaction['type'] == 'DEBIT']

    breakdown = {}
    for debit in debits:
        tag = debit['tag']
        if tag not in breakdown:
            breakdown[tag] = 0.00
        breakdown[tag] = breakdown[tag] + float(debit['amount'])

    return corsify_actual_response(breakdown)


def corsify_actual_response(response):
    response = flask.make_response(response)
    response.headers.add("Access-Control-Allow-Origin", "*")
    print(response);
    return response


if __name__ == '__main__':
    app.run(debug=True)
